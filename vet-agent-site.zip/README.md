# HTM Cloudflare Pages Site

This is a simple static website template built with HTM (Hyperscript Tagged Markup) and Preact, designed for deployment on Cloudflare Pages.

## What is HTM?

HTM is a JSX-like syntax in plain JavaScript that doesn't require any build step or transpilation. It allows you to write component-based UIs similar to React but with vanilla JavaScript.

## Project Structure

```
cloudflare-site/
├── index.html         # Minimal HTML file that loads HTM and Preact
├── css/
│   └── styles.css     # CSS styles
├── js/
│   └── script.js      # HTM/Preact components and application logic
└── README.md          # This file
```

## Features

- Component-based architecture using HTM and Preact
- No build tools required - works directly in the browser
- State management with Preact hooks
- Responsive design
- Form handling with validation

## Deployment Instructions

To deploy this site to Cloudflare Pages:

1. Create a GitHub repository and push this code to it
2. Log in to your Cloudflare dashboard
3. Navigate to Pages
4. Click "Create a project"
5. Connect your GitHub account and select your repository
6. Configure your build settings:
   - Build command: (leave empty for static site)
   - Build output directory: / (or specify cloudflare-site if in a subfolder)
7. Click "Save and Deploy"

## Local Development

To test this site locally, you can use any local server. For example:

```bash
# If you have Python installed:
python -m http.server

# If you have Node.js installed:
npx serve
```

Then visit `http://localhost:8000` or the URL provided by your local server.

## Customization

Feel free to modify the components in script.js to suit your needs. The HTM structure makes it easy to add new components or modify existing ones.
